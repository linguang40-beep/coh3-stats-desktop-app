import {
  Box,
  Group,
  Stack,
  Divider,
  Input,
  ActionIcon,
  Text,
  Button,
  Tooltip,
  Checkbox,
  Slider,
  Anchor,
  Switch,
  Spoiler,
  Select,
  Modal,
  Image,
} from "@mantine/core";
import { appDataDir } from "@tauri-apps/api/path";
import { writeText } from "@tauri-apps/plugin-clipboard-manager";
import React, { useEffect, useState } from "react";
import { IconCheck, IconCopy, IconInfoCircle, IconPlayerPlay, IconX } from "@tabler/icons-react";
import { open } from "@tauri-apps/plugin-dialog";
import { open as openLink } from "@tauri-apps/plugin-shell";
import {
  useLogFilePath,
  useMapViewSettings,
  useShowExtendedPlayerInfo,
  usePlaybackPath,
} from "../game-data-provider/configValues";
import { emit } from "@tauri-apps/api/event";
import { usePlaySound, usePlaySoundVolume } from "../game-found/gameSoundConfigValues";
import { useAutoSwitchToGame } from "../game-found/autoSwitchConfigValues";
import { useBringToFrontOnGameFound } from "../game-found/bringToFrontConfigValues";
import { useAutoMuteEnabled, useMuteOnlyOutOfGame } from "../game-found/audioMuteConfigValues";
import { useGameOverlayEnabled } from "../game-found/gameOverlayConfigValues";
import {
  useShowFlagsOverlay,
  useAlwaysShowOverlay,
  useStreamerOverlayEnabled,
} from "../streamer-overlay/configValues";
import { playSound as playSoundFunc } from "../game-found/playSound";
import events from "../mixpanel/mixpanel";
import { useGameData } from "../game-data-provider/GameDataProvider";
import { relaunch } from "@tauri-apps/plugin-process";
import { getMapsUrlOnCDN } from "../utils/utils";
import { MapViewSettings } from "../game-data-provider/GameData-types";
import { ColorSchemeToggle } from "../components/ToggleCollorShemeButton";
import { useFontScale } from "../config-store/fontScaleConfig";
import config from "../config";
import { Link } from "react-router";
import { Routes } from "../Router";

export const Settings: React.FC = () => {
  const gameData = useGameData();
  const [logFilePath, setLogFilePath] = useLogFilePath();
  const [playbackPath, setPlaybackPath] = usePlaybackPath();
  const [playSound, setPlaySound] = usePlaySound();
  const [playSoundVolume, setPlaySoundVolume] = usePlaySoundVolume();
  const [autoSwitchToGame, setAutoSwitchToGame] = useAutoSwitchToGame();
  const [bringToFrontOnGameFound, setBringToFrontOnGameFound] = useBringToFrontOnGameFound();
  const [autoMuteEnabled, setAutoMuteEnabled] = useAutoMuteEnabled();
  const [muteOnlyOutOfGame, setMuteOnlyOutOfGame] = useMuteOnlyOutOfGame();
  const [gameOverlayEnabled, setGameOverlayEnabled] = useGameOverlayEnabled();
  const [showFlagsOverlay, setShowFlagsOverlay] = useShowFlagsOverlay();
  const [alwaysShowOverlay, setAlwaysShowOverlay] = useAlwaysShowOverlay();
  const [mapViewSettings, setMapViewSettings] = useMapViewSettings();
  const [showExtendedPlayerInfo, setShowExtendedPlayerInfo] = useShowExtendedPlayerInfo();
  const [fontScale, setFontScale] = useFontScale();

  const [streamerOverlayEnabled, setStreamerOverlayEnabled] = useStreamerOverlayEnabled();
  const [appDataPath, setAppDataPath] = useState<string>("");
  const [restartRequired, setRestartRequired] = useState<boolean>(false);
  const [friendsGroupModalOpened, setFriendsGroupModalOpened] = useState<boolean>(false);
  const [gameOverlayModalOpened, setGameOverlayModalOpened] = useState<boolean>(false);

  useEffect(() => {
    events.open_settings();
  }, []);

  useEffect(() => {
    const getAppDataPath = async () => {
      const path = await appDataDir();
      setAppDataPath(path);
    };
    if (appDataPath === "") {
      getAppDataPath();
    }
  }, [appDataPath]);

  const openLogfileDialog = async () => {
    const selected = await open({
      title: "选择《英雄连3》的 warnings.log 文件",
      multiple: false,
      directory: false,
      defaultPath: logFilePath,
      filters: [
        {
          name: "Logfile",
          extensions: ["log"],
        },
      ],
    });
    if (selected !== null) {
      events.settings_changed("logFilePath", selected as string);
      setLogFilePath(selected as string);
    }
  };

  const openPlaybackDialog = async () => {
    const selected = await open({
      title: "选择《英雄连3》的录像目录",
      multiple: false,
      directory: true,
      defaultPath: playbackPath,
    });
    if (selected !== null) {
      events.settings_changed("playbackPath", selected as string);
      setPlaybackPath(selected as string).then(() => emit("playback-dir-changed", selected));
    }
  };

  return (
    <>
      <Box p="xl" pt={"md"}>
        <Stack>
          <Tooltip
            multiline
            w={600}
            label={
              "If the app is stuck loading, you most likely have the wrong path. This often happens when you have OneDrive, Dropbox, or similar services installed. Please locate the correct warnings.log file. The default path is: C:\\Users\\Username\\Documents\\My Games\\Company of Heroes 3\\warnings.log"
            }
          >
            <div>
              应用需要正确的《英雄连3》warnings.log 文件路径才能运行。{" "}
              <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
            </div>
          </Tooltip>
          <Group>
            <div>warnings.log 路径：</div>
            <div>
              <Group gap="xs">
                <Group gap={"xs"}>
                  <Input
                    value={logFilePath ? logFilePath : ""}
                    style={{ width: 500 }}
                    readOnly
                    data-testid="log-file-path-input"
                  />
                  <Button variant="default" onClick={openLogfileDialog}>
                    选择
                  </Button>
                </Group>
                <Tooltip
                  label={logFilePath !== undefined ? "已找到日志文件" : "未找到日志文件"}
                >
                  <ActionIcon
                    variant="light"
                    color={logFilePath !== undefined ? "green" : "red"}
                    radius="xl"
                  >
                    {logFilePath !== undefined ? (
                      <IconCheck size="1.125rem" />
                    ) : (
                      <IconX size="1.125rem" />
                    )}
                  </ActionIcon>
                </Tooltip>
              </Group>
            </div>
          </Group>
          {/* Playback directory section hidden - kept for potential future use */}
          {false && (
            <>
              <Tooltip
                multiline
                w={650}
                label={
                  "This is the path to the folder where your game stores replay files. The default path is: C:\\Users\\Username\\Documents\\My Games\\Company of Heroes 3\\playback. Sometimes when you have OneDrive, Dropbox, or similar services installed, this path might be different."
                }
              >
                <div>
                  Path to playback directory.{" "}
                  <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
                </div>
              </Tooltip>
              <Group>
                <div>录像文件夹路径：</div>
                <div>
                  <Group gap="xs">
                    <Group gap={"xs"}>
                      <Input
                        value={playbackPath ? playbackPath : ""}
                        style={{ width: 500 }}
                        readOnly
                        data-testid="playback-path-input"
                      />
                      <Button variant="default" onClick={openPlaybackDialog}>
                        选择
                      </Button>
                    </Group>
                    <Tooltip
                      label={
                        playbackPath !== undefined
                          ? "已找到录像目录"
                          : "未找到录像目录"
                      }
                    >
                      <ActionIcon
                        variant="light"
                        color={playbackPath !== undefined ? "green" : "red"}
                        radius="xl"
                      >
                        {playbackPath !== undefined ? (
                          <IconCheck size="1.125rem" />
                        ) : (
                          <IconX size="1.125rem" />
                        )}
                      </ActionIcon>
                    </Tooltip>
                  </Group>
                </div>
              </Group>
            </>
          )}
          <Divider />
          <Text fw={700}>发现对局时</Text>
          <Stack gap="md" pl="md">
            <Group>
              <Checkbox
                checked={playSound === undefined ? false : playSound}
                onChange={(event) => {
                  events.settings_changed("play_sound", `${event.currentTarget.checked}`);
                  setPlaySound(event.currentTarget.checked);
                }}
              />
              <div>播放提示音</div>
              <Tooltip label="播放提示音">
                <ActionIcon radius="xl" variant="filled" color="blue" onClick={playSoundFunc}>
                  <IconPlayerPlay size="1.125rem" />
                </ActionIcon>
              </Tooltip>
              <Text>音量</Text>
              <Slider
                min={0.1}
                max={1}
                step={0.1}
                style={{ width: "100px" }}
                label={playSoundVolume ? <>{playSoundVolume.toFixed(1)}</> : null}
                value={playSoundVolume}
                onChange={setPlaySoundVolume}
                onChangeEnd={(value) => {
                  events.settings_changed("play_sound_volume", value);
                }}
              />
            </Group>

            <Group>
              <div>
                <Checkbox
                  checked={autoSwitchToGame === undefined ? true : autoSwitchToGame}
                  onChange={(event) => {
                    events.settings_changed(
                      "auto_switch_to_game",
                      `${event.currentTarget.checked}`,
                    );
                    setAutoSwitchToGame(event.currentTarget.checked);
                  }}
                />
              </div>
              <Tooltip
                multiline
                w={450}
                label="发现对局时自动切换到对战页面。"
              >
                <div>
                  切换到对战页面 <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
                </div>
              </Tooltip>
            </Group>

            <Group>
              <div>
                <Checkbox
                  checked={
                    bringToFrontOnGameFound === undefined ? false : bringToFrontOnGameFound
                  }
                  onChange={(event) => {
                    events.settings_changed(
                      "bring_to_front_on_game_found",
                      `${event.currentTarget.checked}`,
                    );
                    setBringToFrontOnGameFound(event.currentTarget.checked);
                  }}
                />
              </div>
              <Tooltip
                multiline
                w={450}
                label="在 Windows 中将应用窗口置于其他窗口前方。"
              >
                <div>
                  将应用置于前台 <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
                </div>
              </Tooltip>
            </Group>
          </Stack>
          <Divider />
          <Text fw={700}>游戏声音控制</Text>
          <Stack gap="md" pl="md">
            <Group>
              <div>
                <Checkbox
                  checked={autoMuteEnabled ?? true}
                  onChange={(event) => {
                    events.settings_changed("autoMuteEnabled", `${event.currentTarget.checked}`);
                    setAutoMuteEnabled(event.currentTarget.checked);
                  }}
                />
              </div>
              <Tooltip
                multiline
                w={300}
                label="游戏窗口失去焦点时，自动将《英雄连3》静音"
              >
                <div>
                  游戏不在前台时自动静音{" "}
                  <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
                </div>
              </Tooltip>
            </Group>

            <Group>
              <div>
                <Checkbox
                  disabled={!autoMuteEnabled}
                  checked={muteOnlyOutOfGame ?? false}
                  onChange={(event) => {
                    events.settings_changed(
                      "muteOnlyOutOfGame",
                      `${event.currentTarget.checked}`,
                    );
                    setMuteOnlyOutOfGame(event.currentTarget.checked);
                  }}
                />
              </div>
              <Tooltip
                multiline
                w={300}
                label="启用后，仅在菜单中静音，加载或对战时不会静音。注意：游戏和菜单状态的检测并非完全准确。"
              >
                <div>
                  仅在菜单中静音 <IconInfoCircle size={20} style={{ marginBottom: -4 }} />
                </div>
              </Tooltip>
            </Group>
          </Stack>
          <Divider mt={"md"} />
          <Group gap="xs">
            <Text fw={700}>支持者功能</Text>
            <Tooltip
              multiline
              w={400}
              label="由于需要大量 API 请求，支持者功能仅在 Microsoft Store 版本中提供。点击了解获取方式。"
            >
              <Anchor component={Link} to={Routes.ABOUT} c="dimmed" display={"flex"}>
                <IconInfoCircle size={20} />
              </Anchor>
            </Tooltip>
          </Group>
          <Stack gap="md" pl="md">
            {/* This is the overlay drawn on top of the game itself. Not to be confused
                with the OBS Streamer Overlay section below, which is for viewers. */}
            <Group>
              {config.MS_STORE_EDITION ? (
                <Switch
                  data-testid="game-overlay-toggle"
                  aria-label="游戏内对阵悬浮窗"
                  onLabel="ON"
                  offLabel="OFF"
                  size="md"
                  checked={gameOverlayEnabled === undefined ? false : gameOverlayEnabled}
                  onChange={(event) => {
                    events.settings_changed(
                      "gameOverlayEnabled",
                      `${event.currentTarget.checked}`,
                    );
                    setGameOverlayEnabled(event.currentTarget.checked);
                  }}
                />
              ) : (
                <Tooltip
                  multiline
                  w={300}
                  label="由于需要大量 API 请求，游戏内对阵悬浮窗仅在 Microsoft Store 版本中提供。"
                >
                  <div>
                    <Switch
                      data-testid="game-overlay-toggle"
                      aria-label="游戏内对阵悬浮窗"
                      disabled
                      onLabel="ON"
                      offLabel="OFF"
                      size="md"
                      checked={false}
                    />
                  </div>
                </Tooltip>
              )}
              <Text fw={500}>游戏内对阵悬浮窗</Text>
              <Button
                variant="default"
                size="compact-xs"
                onClick={() => setGameOverlayModalOpened(true)}
              >
                了解详情
              </Button>
            </Group>
            <Text size="sm" c="dimmed">
              在游戏加载画面上显示双方队伍。需要使用无边框或窗口模式，不支持独占全屏。
            </Text>

            <Group>
              <Tooltip
                label={
                  "由于需要大量 API 请求，好友组检测仅在 Microsoft Store 版本中提供。"
                }
              >
                <div>
                  <Switch
                    data-testid="friends-group-detection-toggle"
                    aria-label="好友组检测"
                    disabled
                    onLabel="ON"
                    offLabel="OFF"
                    size="md"
                    checked={config.MS_STORE_EDITION}
                  />
                </div>
              </Tooltip>
              <Text fw={500}>好友组检测</Text>
              <Button
                variant="default"
                size="compact-xs"
                onClick={() => setFriendsGroupModalOpened(true)}
              >
                了解详情
              </Button>
            </Group>
            <Text size="sm" c="dimmed">
              除默认的预组队伍检测外，还可识别不完整的预组队伍和跨队伍的潜在好友组。
            </Text>
          </Stack>

          <Modal
            opened={friendsGroupModalOpened}
            onClose={() => setFriendsGroupModalOpened(false)}
            title="好友组检测"
            size="xl"
            centered
          >
            <Stack gap="sm">
              <Text size="sm">
                默认的预组队伍检测仅适用于整组玩家曾一起组队的情况。好友组检测还可显示不完整的队伍（例如三人组队加一名随机玩家），并可跨队伍识别可能的好友组，包括从未一起对战过的好友。
              </Text>
              <Text size="sm" fw={700}>
                由于需要大量 API 请求，好友组检测仅在 Microsoft Store 版本中提供。{" "}
              </Text>
              <Text size="sm" fw={700}>
                <Anchor component={Link} to={Routes.ABOUT}>
                  了解 Microsoft Store 版本
                </Anchor>
              </Text>
              <Image
                src="/friends-group-detection.png"
                alt="Friends Groups Detection Example"
                style={{ borderRadius: 7 }}
              />
            </Stack>
          </Modal>

          <Modal
            opened={gameOverlayModalOpened}
            onClose={() => setGameOverlayModalOpened(false)}
            title="游戏内对阵悬浮窗"
            size="95%"
            styles={{ content: { maxWidth: 1920 } }}
            centered
          >
            <Stack gap="sm">
              <Text size="sm">
                对局加载时，悬浮窗在游戏上方显示双方阵营、国家、排名、ELO、胜负记录以及预组队伍或好友组信息。对局开始后悬浮窗自动消失，不会抢占焦点或拦截鼠标点击。
              </Text>
              <Text size="sm" fw={700}>
                需要《英雄连3》以无边框或窗口模式运行，不支持独占全屏。
              </Text>
              {!config.MS_STORE_EDITION && (
                <>
                  <Text size="sm" fw={700}>
                    由于需要大量 API 请求，游戏内对阵悬浮窗仅在 Microsoft Store 版本中提供。
                  </Text>
                  <Text size="sm" fw={700}>
                    <Anchor component={Link} to={Routes.ABOUT}>
                      了解 Microsoft Store 版本
                    </Anchor>
                  </Text>
                </>
              )}
              <Image
                src="/overlay-example.webp"
                alt="In-Game Matchup Overlay Example"
                style={{ borderRadius: 7 }}
              />
            </Stack>
          </Modal>
          <Divider />
          <Group>
            <Checkbox
              data-testid="show-extended-player-info-checkbox"
              checked={showExtendedPlayerInfo === undefined ? false : showExtendedPlayerInfo}
              onChange={(event) => {
                events.settings_changed(
                  "show_extended_player_info",
                  `${event.currentTarget.checked}`,
                );
                setShowExtendedPlayerInfo(event.currentTarget.checked);
              }}
            />
            <Tooltip
              multiline
              w={600}
              label="显示该阵营的最佳排名及对应模式、该阵营所有模式的总胜率，以及全部对局的总体胜率。"
            >
              <div>
                Show extended player info{" "}
                <IconInfoCircle size={20} style={{ marginBottom: -4 }} />{" "}
              </div>
            </Tooltip>

            <div>
              <Group>
                <img
                  src={`example-extended-player-${showExtendedPlayerInfo ? "" : "no"}info.webp`}
                  alt="MapExample"
                  // width={250}
                  height={70}
                  style={{
                    // objectFit: "cover",
                    borderRadius: 7,
                  }}
                />
              </Group>
            </div>
          </Group>
          <Group>
            <Select
              label={<Text>选择地图标记样式</Text>}
              allowDeselect={false}
              withCheckIcon={false}
              value={mapViewSettings}
              data={[
                { value: "default", label: "默认" },
                { value: "tm", label: "TM" },
                { value: "colored", label: "彩色" },
                { value: "none", label: "无" },
              ]}
              onChange={(value) => {
                events.settings_changed("mapViewSettings", `${value}`);
                setMapViewSettings(value as "string");
              }}
            />
            <img
              src={
                getMapsUrlOnCDN("catania_crossing_6p", mapViewSettings as MapViewSettings) || ""
              }
              alt="MapExample"
              width={250}
              height={50}
              style={{
                objectFit: "cover",
                borderRadius: 7,
              }}
            />
          </Group>
          <Group>
            <div data-testid="color-scheme-toggle">
              <ColorSchemeToggle />
            </div>
            <div>配色主题</div>
          </Group>
          <Group>
            <div>字体大小：</div>
            <Group gap="md">
              <Slider
                min={0.7}
                max={1.2}
                step={0.1}
                style={{ width: "200px" }}
                label={(value) => `${Math.round(value * 100)}%`}
                value={fontScale ?? 1.0}
                onChange={setFontScale}
                onChangeEnd={(value) => {
                  events.settings_changed("fontScale", value);
                }}
                marks={[
                  { value: 0.7, label: "70%" },
                  { value: 0.8, label: "80%" },
                  { value: 0.9, label: "90%" },
                  { value: 1.0, label: "100%" },
                  { value: 1.1, label: "110%" },
                  { value: 1.2, label: "120%" },
                ]}
              />
            </Group>
          </Group>
          <Divider mt={"md"} />
          <Group>
            <Text fw={700}>OBS 直播悬浮窗</Text>
            <Switch
              data-testid="obs-overlay-toggle"
              onLabel="ON"
              offLabel="OFF"
              size="md"
              checked={streamerOverlayEnabled === undefined ? false : streamerOverlayEnabled}
              onChange={(event) => {
                events.settings_changed(
                  "streamerOverlayEnabled",
                  `${event.currentTarget.checked}`,
                );
                setStreamerOverlayEnabled(event.currentTarget.checked);
                setRestartRequired(true);
              }}
            />
          </Group>
          <Group>
            <div>
              {restartRequired ? (
                <Group>
                  <Text c="red">启用或关闭直播悬浮窗需要重启应用</Text>
                  <Button
                    data-testid="obs-restart-button"
                    variant="outline"
                    color="red"
                    size="compact-md"
                    onClick={async () => {
                      // Relaunch doesn't work well in dev mode
                      await relaunch();
                    }}
                  >
                    重启
                  </Button>
                </Group>
              ) : null}
            </div>
          </Group>
          <Group>
            <div>
              <Checkbox
                data-testid="obs-only-show-ingame-checkbox"
                disabled={streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled}
                checked={alwaysShowOverlay === undefined ? true : !alwaysShowOverlay}
                onChange={(event) => {
                  events.settings_changed("alwaysShowOverlay", `${!event.currentTarget.checked}`);
                  setAlwaysShowOverlay(!event.currentTarget.checked);
                  if (gameData) {
                    gameData.reloadLogFile();
                  }
                }}
              />
            </div>
            <div>仅在加载或对战中显示数据</div>
          </Group>
          <Group>
            <div>
              <Checkbox
                data-testid="obs-show-flags-checkbox"
                disabled={streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled}
                checked={showFlagsOverlay === undefined ? false : showFlagsOverlay}
                onChange={(event) => {
                  events.settings_changed("showFlagsOverlay", `${event.currentTarget.checked}`);
                  setShowFlagsOverlay(event.currentTarget.checked);
                  if (gameData) {
                    gameData.reloadLogFile();
                  }
                }}
              />
            </div>
            <div>显示国旗</div>
          </Group>
          <div>
            <Text fw={700}>
              Follow the{" "}
              <Anchor
                inherit
                onClick={() =>
                  openLink(
                    "https://github.com/cohstats/coh3-stats-desktop-app#setup-obs-streamer-overlay",
                  )
                }
              >
                设置说明
              </Anchor>{" "}
              &{" "}
              <Anchor
                onClick={() =>
                  openLink(
                    "https://github.com/cohstats/coh3-stats-desktop-app#custom-css-for-the-overlay",
                  )
                }
              >
                自定义 CSS 说明
              </Anchor>
            </Text>
          </div>
          <Group>
            <Text>直播悬浮窗地址：</Text>
            <Input
              value={"http://localhost:47824"}
              style={{ width: 250 }}
              readOnly
              disabled={streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled}
            />
            <Tooltip label="复制">
              <ActionIcon
                disabled={streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled}
                onClick={() => {
                  writeText("http://localhost:47824");
                }}
              >
                <IconCopy size="1.125rem" />
              </ActionIcon>
            </Tooltip>
          </Group>
          <Spoiler
            maxHeight={0}
            showLabel="已弃用——本地 streamerOverlay.html 文件"
            hideLabel="收起"
          >
            <div style={{ paddingLeft: 10 }}>
              <Text>
                本地文件刷新时可能闪烁，建议使用本地网页服务器避免此问题。
              </Text>
              <Group>
                <Text>streamerOverlay.html 路径：</Text>
                <Input
                  value={appDataPath}
                  style={{ width: 500 }}
                  readOnly
                  disabled={
                    streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled
                  }
                />
                <Tooltip label="复制">
                  <ActionIcon
                    disabled={
                      streamerOverlayEnabled === undefined ? false : !streamerOverlayEnabled
                    }
                    onClick={() => {
                      writeText(appDataPath);
                    }}
                  >
                    <IconCopy size="1.125rem" />
                  </ActionIcon>
                </Tooltip>
              </Group>
            </div>
          </Spoiler>
        </Stack>
      </Box>
    </>
  );
};
