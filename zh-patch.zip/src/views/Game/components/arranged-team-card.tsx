import React, { useEffect, useState } from "react";
import { Paper, Text, Group, Stack, Loader, Badge, Tooltip, Anchor } from "@mantine/core";
import { IconInfoCircle } from "@tabler/icons-react";
import { open } from "@tauri-apps/plugin-shell";
import { FullPlayerData, TeamSide } from "../../../game-data-provider/GameData-types";
import { TeamDetails } from "../../../utils/data-types";
import { coh3statsTeamDetails } from "../../../utils/external-routes";
import { KnownFriendsGroup } from "../../../utils/team-grouping";
import { detectArrangedTeam } from "../../../utils/arranged-team-detection";

interface ArrangedTeamCardProps {
  players: FullPlayerData[];
  side: TeamSide;
  onTeamGroupsChange?: (groups: KnownFriendsGroup[]) => void;
}

export const ArrangedTeamCard: React.FC<ArrangedTeamCardProps> = ({
  players,
  side,
  onTeamGroupsChange,
}) => {
  const [teamData, setTeamData] = useState<TeamDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [teamGroups, setTeamGroups] = useState<KnownFriendsGroup[]>([]);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setError(null);
        setTeamGroups([]); // Clear team groups at the start

        // Shared with the in-game overlay - see utils/arranged-team-detection.ts
        const { team, groups } = await detectArrangedTeam(players, side);
        setTeamData(team);

        if (groups.length > 0) {
          setTeamGroups(groups);
          onTeamGroupsChange?.(groups);
        } else if (team) {
          // Clear team groups when a team is found
          onTeamGroupsChange?.([]);
        }
      } catch (err) {
        // If team is not found or any other error, don't render the component
        console.log("Arranged team not found or error occurred:", err);
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    })();
  }, [players, side]);

  // Don't render anything while loading
  if (loading) {
    return (
      <Paper shadow="xs" withBorder p="xs" mb="xs">
        <Group justify="center">
          <Loader size="sm" />
          <Text size="sm" c="dimmed">
            正在检测预组队伍…
          </Text>
        </Group>
      </Paper>
    );
  }

  // If no team found or error occurred, show team groups or random team info
  if (error || !teamData) {
    // If we have team groups, show them
    if (teamGroups.length > 0) {
      return (
        <Paper shadow="xs" withBorder p="xs" mb="xs">
          <Group justify="center" align="center" pos="relative">
            {teamGroups.map((group, index) => {
              const playerNames = group.playerIds
                .map((playerId) => {
                  const player = players.find((p) => parseInt(p.relicID, 10) === playerId);
                  return player?.name || `Player ${playerId}`;
                })
                .join(", ");

              return (
                <Tooltip
                  key={index}
                  label={`Known Friends: ${playerNames}`}
                  multiline
                  w={300}
                  withArrow
                >
                  <Badge color={group.color} variant="filled">
                    好友组
                  </Badge>
                </Tooltip>
              );
            })}
            <Tooltip
              label="这些玩家曾以不同组合一起对战，很可能正在组队。"
              multiline
              w={300}
              withArrow
              style={{ position: "absolute", right: 0 }}
            >
              <IconInfoCircle size={18} style={{ color: "var(--mantine-color-dimmed)" }} />
            </Tooltip>
          </Group>
        </Paper>
      );
    }

    // No team groups found, show random team
    return (
      <Paper shadow="xs" withBorder p="xs" mb="xs">
        <Group justify="center" align="center" pos="relative">
          <Badge color="gray" variant="filled">
            随机队伍
          </Badge>
          <Tooltip
            label="It's still possible that this team is not yet tracked by coh3stats, head over to the about page to learn more about arranged teams."
            multiline
            w={300}
            withArrow
            style={{ position: "absolute", right: 0 }}
          >
            <IconInfoCircle size={18} style={{ color: "var(--mantine-color-dimmed)" }} />
          </Tooltip>
        </Group>
      </Paper>
    );
  }

  // Calculate win/loss ratio
  const winLossRatio = teamData.t > 0 ? Math.round((teamData.w / teamData.t) * 100) : 0;

  // Generate team details URL using the team ID and first player ID from the API response
  const firstPlayerId = teamData.players[0]?.profile_id;
  const teamDetailsUrl =
    firstPlayerId && teamData.id ? coh3statsTeamDetails(firstPlayerId, teamData.id) : null;

  return (
    <Paper shadow="xs" withBorder p="xs" mb="xs">
      <Group justify="center" align="center">
        {teamDetailsUrl ? (
          <Anchor onClick={() => open(teamDetailsUrl)}>
            <Badge color="blue" variant="filled" style={{ cursor: "pointer" }}>
              预组队伍
            </Badge>
          </Anchor>
        ) : (
          <Badge color="blue" variant="filled">
            预组队伍
          </Badge>
        )}

        <Group gap="md">
          <Tooltip label="ELO 评分" withArrow>
            <Text>{teamData.elo}</Text>
          </Tooltip>
          <Text c={teamData.s > 0 ? "green" : teamData.s < 0 ? "red" : "gray"}>
            {teamData.s > 0 ? `+${teamData.s}` : teamData.s}
          </Text>
          <Text>{winLossRatio}%</Text>
          <Text c="green">{teamData.w} W</Text>
          <Text c="red">{teamData.l} L</Text>
        </Group>
      </Group>
    </Paper>
  );
};
