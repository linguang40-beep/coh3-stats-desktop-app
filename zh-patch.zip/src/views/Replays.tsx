import { Box, Text, Anchor, Paper, Title, Stack } from "@mantine/core";
import { useEffect } from "react";
import { open as openLink } from "@tauri-apps/plugin-shell";
import events from "../mixpanel/mixpanel";
import { COHDBIcon } from "../components/other/COHDB-icon";
import config from "../config";

export const Replays: React.FC = () => {
  useEffect(() => {
    events.open_replays().then();
  }, []);

  return (
    <Box p="xl" pt={"md"}>
      <Paper p="md">
        <Stack gap="md">
          <Title order={3}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: "8px" }}>
              <COHDBIcon size={24} /> 录像分析
            </span>
          </Title>
          <Text size="lg" data-testid="replays-description">
            访问{" "}
            <Anchor onClick={() => openLink(config.COHDB_BASE_URL)} fw={700}>
              cohdb.com
            </Anchor>{" "}
            上传并分析《英雄连3》录像。
          </Text>
          <Text>
            COHDB 提供全面的录像分析工具，帮助你复盘对局、提升水平。
          </Text>
          <Text>
            你也可以访问{" "}
            <Anchor onClick={() => openLink("https://coh3stats.com")} fw={700}>
              coh3stats.com
            </Anchor>{" "}
            查看更多数据和排行榜。
          </Text>
        </Stack>
      </Paper>
    </Box>
  );
};
