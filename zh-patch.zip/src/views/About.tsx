import { getVersion, getName } from "@tauri-apps/api/app";
import { appLocalDataDir } from "@tauri-apps/api/path";
import { open } from "@tauri-apps/plugin-shell";
import { fetch } from "@tauri-apps/plugin-http";
import React, { useState, useEffect } from "react";
import {
  Title,
  Code,
  Text,
  Group,
  Anchor,
  Divider,
  Button,
  Grid,
  Space,
  Box,
} from "@mantine/core";
import { IconDownload, IconBrandWindows } from "@tabler/icons-react";
import logoBig from "../assets/logo/Square310x310Logo.png";
import events from "../mixpanel/mixpanel";
import config from "../config";
import { DiscordIcon } from "../components/other/Discord-icon";
import { useUpdater } from "../providers/UpdaterProvider";

/**
 * Compare two semantic version strings
 * @param version1 - First version string (e.g., "2.0.1")
 * @param version2 - Second version string (e.g., "2.0.0")
 * @returns -1 if version1 < version2, 0 if equal, 1 if version1 > version2
 */
const compareVersions = (version1: string, version2: string): number => {
  const v1Parts = version1.split(".").map(Number);
  const v2Parts = version2.split(".").map(Number);

  const maxLength = Math.max(v1Parts.length, v2Parts.length);

  for (let i = 0; i < maxLength; i++) {
    const v1Part = v1Parts[i] || 0;
    const v2Part = v2Parts[i] || 0;

    if (v1Part < v2Part) return -1;
    if (v1Part > v2Part) return 1;
  }

  return 0;
};

export const About: React.FC = () => {
  const [appVersion, setAppVersion] = useState<string>();
  const [pathToLogs, setPathToLogs] = useState<string>();
  const [appName, setAppName] = useState<string>();

  const [latestVersion, setLatestVersion] = useState<string>();

  const { checkForUpdates, updateAvailable, isChecking, showUpdateModal } = useUpdater();

  useEffect(() => {
    (async () => {
      getVersion().then((version) => setAppVersion(version));
      events.open_about();
      appLocalDataDir().then((path) => setPathToLogs(path));
      getName().then((name) => setAppName(name));

      fetch(config.COHS3STATS_API_UPDATE_ROUTE)
        .then(async (response) => {
          const data = await response.json();
          setLatestVersion(data.version.replace("v", ""));
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    })();
  }, []);

  return (
    <Box p="xl" pt={"md"}>
      {/* Top section with logo and version info */}
      <Grid style={{ margin: 0 }}>
        <Grid.Col span="auto">
          <Title size="h3">关于 - {appName}</Title>
          <Divider p="xs" mt={"xs"} />
          <Group gap="xs">
            <Title order={4}>版本 </Title>
            <Code color="green" data-testid="app-version">
              {appVersion}
            </Code>
          </Group>
          {config.MS_STORE_EDITION && (
            <Text component="p" size="sm" c="dimmed" mt="xs">
              Microsoft Store 版本——更新由 Microsoft Store 管理
            </Text>
          )}
          {!config.MS_STORE_EDITION &&
            latestVersion !== appVersion &&
            latestVersion !== undefined &&
            appVersion &&
            (() => {
              const versionComparison = compareVersions(appVersion, latestVersion);

              if (versionComparison < 0) {
                // Current version is older than latest
                return (
                  <>
                    <Space h="xs" />
                    <Text component="p" size="sm" c={"red"}>
                      最新正式版为 {latestVersion}。
                    </Text>
                    <Group gap="xs" mt="xs">
                      <Button
                        size="xs"
                        leftSection={<IconDownload size={16} />}
                        onClick={() => {
                          if (updateAvailable) {
                            showUpdateModal();
                          } else {
                            checkForUpdates();
                          }
                        }}
                        loading={isChecking}
                      >
                        {updateAvailable ? "安装更新" : "检查更新"}
                      </Button>
                      <Text component="span" size="sm" c="dimmed">
                        或{" "}
                        <Anchor
                          href="https://coh3stats.com/desktop-app"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          手动下载
                        </Anchor>
                      </Text>
                    </Group>
                    <Space h="xs" />
                  </>
                );
              } else if (versionComparison > 0) {
                // Current version is newer than latest
                return (
                  <>
                    <Space h="xs" />
                    <Text component="p" size="sm" c={"yellow"}>
                      当前版本（{appVersion}）比最新公布的稳定版（{latestVersion}）更新。如遇问题，可从以下地址下载最新稳定版：{" "}
                      <Anchor
                        href="https://coh3stats.com/desktop-app"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        coh3stats.com/desktop-app
                      </Anchor>
                      .
                    </Text>
                    <Space h="xs" />
                  </>
                );
              }

              return null;
            })()}
          <Text component="p" size="sm">
            访问我们的网站{" "}
            <Anchor onClick={() => open(config.COH3STATS_BASE_ULR)}>coh3stats.com</Anchor>.
          </Text>
          <Text component="p" size="sm">
            想要提供帮助？{" "}
            <Anchor
              onClick={() => open("https://github.com/cohstats/coh3-stats-desktop-app/issues")}
            >
              报告问题
            </Anchor>
            , <Anchor onClick={() => open("https://coh3stats.com/about")}>捐款</Anchor>{" "}
            或{" "}
            <Anchor onClick={() => open(config.DISCORD_JOIN_LINK)}>
              加入我们的 Discord，参与社区！
            </Anchor>
          </Text>
        </Grid.Col>
        <Grid.Col span="content" pl={"md"}>
          <img src={logoBig} alt="Coh3Stats Logo" width={130} />
        </Grid.Col>
      </Grid>
      <Group>
        {!config.MS_STORE_EDITION ? (
          <Anchor
            href={config.MS_STORE_LINK}
            target="_blank"
            rel="noopener"
            onClick={(e) => {
              e.preventDefault();
              open(config.MS_STORE_LINK);
            }}
          >
            <Button
              size="mg"
              variant="filled"
              leftSection={<IconBrandWindows size={20} style={{ marginLeft: 6 }} />}
            >
              在 Microsoft Store 获取应用
            </Button>
          </Anchor>
        ) : (
          <Button onClick={() => open(config.KOFI_LINK)}>
            <Group gap="xs">
              <img
                src="https://storage.ko-fi.com/cdn/cup-border.png"
                alt="Ko-fi donations"
                width={18}
              />
              捐款
            </Group>
          </Button>
        )}
        <DiscordIcon />
      </Group>
      <Space h={"md"} />

      {/* Full-width content sections */}
      <Divider />
      <Space h={"xs"} />

      <Title order={4}>预组队伍</Title>
      <Text component="p" size="sm">
        <Anchor onClick={() => open("https://coh3stats.com/about#arrangedteams")}>
          了解预组队伍
        </Anchor>{" "}
        及其在《英雄连3》中的工作方式。
      </Text>

      <Space h={"xs"} />
      <Title order={4}>报告问题</Title>
      <Text component="p" size="sm">
        如遇问题，请在 Discord 的 bugs-and-questions 频道报告，并尽可能提供详细信息，包括 warnings.log：{" "}
        <Code> C:\Users\Username\Documents\My Games\Company of Heroes 3\warnings.log</Code>
        <br />
        <br />
        你也可以提供 {appName} 应用的日志，位置如下：
        <br />
        <Code>{pathToLogs}\logs</Code>
      </Text>

      <Space h={"lg"} />
      <Title order={4}>捐款</Title>
      <Text component="p" size="sm">
        COH3 Stats 为《英雄连3》社区提供全面分析和实时数据处理。这些服务需要大量服务器资源和带宽，并持续产生成本。
      </Text>
      <Text component="p" size="sm">
        你的捐款有助于支付服务器费用和改进平台，支持 COH3 Stats 平稳运行。
      </Text>
      <Text component="p" size="sm">
        感谢所有支持者！你们的慷慨帮助我们向整个《英雄连3》社区免费提供这些服务。
      </Text>
      <Space h={"xs"} />
      <Group>
        <Button onClick={() => open(config.KOFI_LINK)}>
          <Group gap="xs">
            <img
              src="https://storage.ko-fi.com/cdn/cup-border.png"
              alt="Ko-fi donations"
              width={18}
            />
            捐款
          </Group>
        </Button>
        <DiscordIcon />
      </Group>

      <Space h={"lg"} />
      <Text component="p" size="sm">
        © 2023 - 2025 COH Stats
      </Text>
    </Box>
  );
};
