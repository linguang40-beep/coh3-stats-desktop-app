import React from "react";
import { Badge, Group, Loader, Image, Tooltip } from "@mantine/core";
import { useGameData } from "../game-data-provider/GameDataProvider";

interface GameStateProps {
  compact?: boolean;
}

export const GameState: React.FC<GameStateProps> = ({ compact = false }) => {
  const gameData = useGameData();

  return (
    <Tooltip
      label="当前游戏状态：菜单、加载中或对战中"
      multiline
      w={250}
      withArrow
    >
      <div>
        <Group gap={"xs"}>
          <Image
            src="/icons/coh3-icon.webp"
            alt="Game State"
            w={compact ? 18 : 24}
            h={compact ? 18 : 24}
            radius={"md"}
          />
          {gameData ? (
            <Badge
              variant="filled"
              size={"md"}
              style={{
                minWidth: 60,
                marginBottom: compact ? 0 : -1,
              }}
            >
              {({ closed: "未运行", menu: "菜单", loading: "加载中", ingame: "对战中" } as Record<string, string>)[gameData.gameData.state.toLowerCase()] ?? gameData.gameData.state}
            </Badge>
          ) : (
            <Loader type="dots" size="md" style={{ minWidth: 60 }} />
          )}
        </Group>
      </div>
    </Tooltip>
  );
};
