import React from "react";
import { error as TauriError } from "@tauri-apps/plugin-log";
import { Code, Space, Stack, Text, Title } from "@mantine/core";
import * as Sentry from "@sentry/react";

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallbackMessage?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(_: Error): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
    TauriError(error.toString());
    // Report error to sentry
    // TODO: Improve this to send also warnings.log file together with this error
    Sentry.captureException(error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Stack align="center" justify="center" style={{ minHeight: "100vh" }}>
          <Title order={2}>出错了。</Title>
          <Text>
            {this.props.fallbackMessage || "There was an error rendering this component. "}
          </Text>
          请在 Discord 中报告此问题，并尽可能提供详细信息。
          <div>
            <Text size="sm">
              请尝试提供以下位置的 warnings.log 文件：
              <br />
              <Code>C:\Users\Username\Documents\My Games\Company of Heroes 3\warnings.log</Code>
            </Text>
            <Space h="md" />
            <Text size="sm">
              也可以提供 COH3 Stats 桌面应用的日志，位置如下：
              <br />
              <Code>C:\Users\Username\AppData\Roaming\com.coh3stats.desktop\logs</Code>
            </Text>
          </div>
        </Stack>
      );
    }

    return this.props.children;
  }
}

export const GameErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error in Game view. Please try refreshing.">
    {children}
  </ErrorBoundary>
);

export const SettingsErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error in Settings view. Please try again later.">
    {children}
  </ErrorBoundary>
);

export const ReplaysErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error loading Replays. Please check your connection.">
    {children}
  </ErrorBoundary>
);

export const AboutErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error loading About page. Please try again.">
    {children}
  </ErrorBoundary>
);

export const RecentGamesErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error loading Recent Games. Please check your connection and try again.">
    {children}
  </ErrorBoundary>
);

export const LeaderboardsErrorBoundary: React.FC<React.PropsWithChildren> = ({ children }) => (
  <ErrorBoundary fallbackMessage="Error loading Leaderboards. Please check your connection and try again.">
    {children}
  </ErrorBoundary>
);

export { ErrorBoundary };
